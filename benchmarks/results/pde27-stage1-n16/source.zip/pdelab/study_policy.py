"""Stable pilot selection, fresh-data retries and readable accuracy results."""

from time import perf_counter

import numpy as np

SELECTION_POLICY = "stable_pilot_adaptive_retry_v6"
ACCURACY_METRIC = "mean_run_relative_l1_v1"
ACCURACY_DESCRIPTION = "100 * mean_runs(sum_points(abs(u_run-reference)) / sum_points(abs(reference))); error of individual runs in the validation series"
CALIBRATION_FRACTION = 0.5
DETERMINISTIC_METHODS = {"lod", "lod_serial", "picard"}


class RetryableSolverError(RuntimeError):
    """An incomplete stochastic solve that may converge at a larger budget."""


def mean_relative_error(values, reference):
    """Mean of absolute relative errors, not RMS or error of the mean.

    For multiple query points use the relative L1 error of each whole query.
    Individual zero reference nodes are included; an all-zero reference is undefined.
    """
    reference = np.asarray(reference, dtype=float)
    values = np.asarray(values, dtype=float)
    if not reference.size or not values.size:
        raise ValueError("Для ошибки нужны непустые значения и эталон")
    if not np.isfinite(reference).all() or not np.isfinite(values).all():
        raise ValueError("Значения и эталон должны быть конечными")
    scale = np.mean(np.abs(reference))
    if scale == 0:
        raise ValueError("Нулевой эталон: относительная ошибка не определена")
    return float(100 * np.mean(np.abs(values - reference)) / scale)


def accuracy_metadata(rows):
    """Never relabel a saved RMS study with the new metric when exporting it."""
    row = rows[0] if rows else {}
    metric = row.get("accuracy_metric", "relative_rmse_v1")
    return dict(
        accuracy_metric=metric,
        accuracy=(
            ACCURACY_DESCRIPTION
            if metric == ACCURACY_METRIC
            else "100 * RMS(u_run-reference) / RMS(reference); individual runs"
        ),
        selection=row.get("selection_policy", "legacy"),
    )


def calibration_target(target, method):
    """Keep the deterministic baseline fair; reserve a margin for random errors."""
    return target if method in DETERMINISTIC_METHODS else target * CALIBRATION_FRACTION


def phase_seed_index(phase):
    """Separate every pilot batch from validation without changing legacy streams."""
    return {
        "calibration": 0,
        "validation": 1,
        "calibration_2": 2,
        "calibration_3": 3,
    }[phase]


def search_budgets(
    method,
    budgets,
    measure,
    seconds_per_phase,
    targets=(1.0, 5.0, 10.0),
    *,
    fastest=False,
    clock=perf_counter,
):
    """Require three stable MC pilots, then retry failures at larger budgets.

    Each (budget index, phase) is measured at most once on separate random data.
    The last check is an adaptive empirical result, not a confidence guarantee.
    Calibration and validation each have one cumulative time allowance, which
    retries do not reset. In fastest mode rank successful candidates by pilot
    time, not by the luckiest validation timing.
    """
    stochastic = method not in DETERMINISTIC_METHODS
    budgets = list(budgets)
    if stochastic:
        budgets = sorted(set(budgets))
    rows = [
        dict(
            method=method,
            target_pct=target,
            seconds=None,
            validation_seconds=None,
            relative_error_pct=None,
            calibration_error_pct=None,
            budget=None,
            interrupted_budget=None,
            budget_kind=(
                "walks_per_start" if stochastic else "relative_residual_tolerance"
            ),
            calibration_target_pct=calibration_target(target, method),
            selection_policy=SELECTION_POLICY,
            accuracy_metric=ACCURACY_METRIC,
            status="Недостаточный запас точности в пределах бюджетов",
            status_code="not_reached",
            validation_attempts=0,
            calibration_margin_relaxed=False,
        )
        for target in targets
    ]
    attempts = []
    spent = {"calibration": 0.0, "validation": 0.0}
    best_pilot_times = {}

    def run_series(budget, index, phase):
        group = "validation" if phase == "validation" else "calibration"
        started = clock()
        remaining = seconds_per_phase - spent[group]
        attempt = dict(budget=budget, budget_index=index, phase=phase)
        try:
            if remaining <= 0:
                raise TimeoutError("Лимит времени")
            result = measure(budget, index, phase, started + remaining)
            if not np.isfinite(result["relative_error_pct"]):
                raise RuntimeError("Неконечная ошибка")
            if not np.isfinite(result["seconds"]) or result["seconds"] < 0:
                raise RuntimeError("Некорректное время расчёта")
            attempt.update(result, status="completed")
            return result
        except (TimeoutError, RuntimeError) as exc:
            attempt.update(
                status="timeout" if isinstance(exc, TimeoutError) else "solver_failed",
                reason=str(exc),
            )
            raise
        finally:
            elapsed = max(0.0, clock() - started)
            spent[group] += elapsed
            attempt["elapsed_seconds"] = elapsed
            attempts.append(attempt)

    for index, budget in enumerate(budgets):
        pending = [r for r in rows if fastest or r["seconds"] is None]
        if not pending:
            break
        at_maximum = stochastic and index == len(budgets) - 1

        def pilot_limit(row):
            return (
                row["target_pct"]
                if at_maximum
                else calibration_target(row["target_pct"], method)
            )

        pilots = []
        try:
            pilots.append(run_series(budget, index, "calibration"))
            # Do not spend extra pilot runs on an already insufficient budget.
            if stochastic and any(
                pilots[0]["relative_error_pct"] <= pilot_limit(r) for r in pending
            ):
                for phase in ("calibration_2", "calibration_3"):
                    pilots.append(run_series(budget, index, phase))
        except (TimeoutError, RuntimeError) as exc:
            for row in pending:
                if row["seconds"] is None:
                    row.update(
                        interrupted_budget=budget,
                        status=(
                            "Лимит времени поиска"
                            if isinstance(exc, TimeoutError)
                            else f"Ошибка решателя: {exc}"
                        ),
                        status_code=(
                            "timeout"
                            if isinstance(exc, TimeoutError)
                            else "solver_failed"
                        ),
                    )
                    if isinstance(exc, RetryableSolverError):
                        # Earlier completed pilots belong to another budget.
                        # Keep them in attempts, not as this failed run's error.
                        row.update(
                            budget=None,
                            calibration_error_pct=None,
                            relative_error_pct=None,
                            validation_seconds=None,
                        )
            if stochastic and isinstance(exc, RetryableSolverError):
                continue
            break
        pilot_error = max(p["relative_error_pct"] for p in pilots)
        pilot_seconds = float(np.mean([p["seconds"] for p in pilots]))
        eligible = []
        for row in pending:
            nominal_limit = calibration_target(row["target_pct"], method)
            relaxed = at_maximum and pilot_error > nominal_limit
            if row["seconds"] is None:
                row.update(
                    budget=budget,
                    calibration_error_pct=pilot_error,
                    relative_error_pct=None,
                    validation_seconds=None,
                    status="Недостаточный запас точности в пределах бюджетов",
                    status_code="not_reached",
                    calibration_target_pct=(
                        pilot_limit(row) if relaxed else nominal_limit
                    ),
                    calibration_margin_relaxed=relaxed,
                )
            if pilot_error <= pilot_limit(row) and (
                row["seconds"] is None
                or pilot_seconds < best_pilot_times[row["target_pct"]]
            ):
                eligible.append(row)
        if not eligible:
            continue
        try:
            confirmation = run_series(budget, index, "validation")
        except (TimeoutError, RuntimeError) as exc:
            for row in eligible:
                row["validation_attempts"] += 1
                if row["seconds"] is None:
                    row.update(
                        status=f"Бюджет найден, проверка не завершена: {exc}",
                        status_code="validation_incomplete",
                    )
            if stochastic and isinstance(exc, RetryableSolverError):
                continue
            break
        error = confirmation["relative_error_pct"]
        for row in eligible:
            row["validation_attempts"] += 1
            passed = error <= row["target_pct"]
            if passed or row["seconds"] is None:
                nominal_limit = calibration_target(row["target_pct"], method)
                relaxed = at_maximum and pilot_error > nominal_limit
                row.update(
                    budget=budget,
                    calibration_error_pct=pilot_error,
                    relative_error_pct=error,
                    validation_seconds=confirmation["seconds"],
                    seconds=confirmation["seconds"] if passed else None,
                    status=(
                        "Достигнута"
                        if passed
                        else "Точность не подтверждена в пределах бюджетов"
                    ),
                    status_code="confirmed" if passed else "validation_failed",
                    calibration_margin_relaxed=relaxed,
                    calibration_target_pct=(
                        row["target_pct"] if relaxed else nominal_limit
                    ),
                )
                if passed:
                    best_pilot_times[row["target_pct"]] = pilot_seconds
        # Unconfirmed targets remain pending at the next (strictly larger) MC budget.
    for row in rows:
        row.update(
            attempts=attempts,
            calibration_seconds=spent["calibration"],
            total_validation_seconds=spent["validation"],
            search_seconds=sum(spent.values()),
        )
    return rows


def readable_status(row):
    status = row.get("status_code", row.get("status", ""))
    labels = {
        "confirmed": "Достигнута",
        "reached": "Достигнута",
        "validation_failed": "Не подтверждена в пределах лимитов",
        "not_confirmed": "Проверка не прошла",
        "not_reached": "Нет запаса точности",
        "budget_exhausted": "Нет запаса точности",
        "timeout": "Лимит времени подбора",
        "time_limit": "Лимит времени подбора",
        "zero_reference": "Нулевой эталон: процент не определён",
        "solver_failed": "Решатель не завершён",
    }
    if status == "validation_incomplete":
        return row.get("status_detail", row["status"])
    if status == "solver_failed":
        reason = row.get("reason") or row.get("status_detail") or row["status"]
        for code, label in {
            "walk_budget": "лимит общего числа путей",
            "validation_budget": "лимит путей контрольной проверки",
            "max_outer": "лимит внешних итераций",
        }.items():
            reason = reason.replace(code, label)
        return reason
    return labels.get(status, row.get("status", str(status)))


def budget_label(row):
    budget = row.get("budget")
    if budget is None:
        budget = row.get("walks")
    if budget is None:
        interrupted = row.get("interrupted_budget")
        if interrupted is None:
            return "не выбран"
        label = (
            f"tol={interrupted:g}"
            if row["method"] in DETERMINISTIC_METHODS
            else f"N={int(interrupted)}"
        )
        return label + " (серия не завершена)"
    if row["method"] in DETERMINISTIC_METHODS:
        return f"tol={budget:g}"
    prefix = "N₀" if row.get("budget_kind") == "initial_walks_per_node" else "N"
    label = f"{prefix}={int(budget):,}".replace(",", " ")
    if prefix == "N₀":
        label += f"; Nmax={row['max_walks']}"
    return label


def error_label(row):
    error = row.get("relative_error_pct", row.get("validation_error_pct"))
    if error is not None:
        return f"проверка {error:.3g}%"
    error = row.get("calibration_error_pct")
    return f"подбор {error:.3g}%" if error is not None else "ошибка ещё не измерена"


def display_timing_rows(rows, names=None):
    """Numeric export stays unchanged; the on-screen matrix has no opaque nulls."""
    names = {} if names is None else names
    result = []
    for target in sorted({r["target_pct"] for r in rows}):
        line = {"Относительная ошибка, %": target}
        for row in rows:
            if row["target_pct"] != target:
                continue
            label = names.get(row["method"], row.get("name", row["method"]))
            if row["seconds"] is not None:
                cell = f"{row['seconds']:.6f} с"
            else:
                cell = (
                    f"{readable_status(row)}\n{budget_label(row)}\n{error_label(row)}"
                )
            line[label] = cell
        result.append(line)
    return result


def render_accuracy_results(rows, names=None, *, key):
    import pandas as pd
    import streamlit as st

    names = {} if names is None else names
    if any(r.get("selection_policy") != SELECTION_POLICY for r in rows):
        st.info(
            "Показано исследование по прежнему протоколу. Запустите заново для устойчивого подбора с повторными попытками."
        )
    else:
        st.caption(
            "Ошибка — среднее относительных ошибок отдельных запусков. MC: три предварительные серии с запасом, затем новая проверка; при неудаче бюджет увеличивается. Это адаптивная проверка, не статистическая гарантия. Время — одного проверочного запуска."
        )
    timing = display_timing_rows(rows, names)
    for line in timing:
        for column, value in line.items():
            if isinstance(value, str) and "\n" in value:
                line[column] = value.split("\n", 1)[0]
    st.dataframe(
        pd.DataFrame(timing), hide_index=True, width="stretch", key=key + "_table"
    )
    targets = sorted({r["target_pct"] for r in rows})
    selected = st.segmented_control(
        "Бюджеты и ошибки для порога",
        targets,
        default=targets[0],
        format_func=lambda target: f"{target:g}%",
        key=key + "_target",
    )
    selected = targets[0] if selected is None else selected
    details = []
    for row in rows:
        if row["target_pct"] != selected:
            continue
        pilot = row.get("calibration_error_pct")
        check = row.get("relative_error_pct", row.get("validation_error_pct"))
        search_seconds = row.get("search_seconds")
        status = readable_status(row)
        if row.get("calibration_margin_relaxed"):
            status += "; максимум путей, без дополнительного запаса"
        interrupted = row.get("interrupted_budget")
        if interrupted is not None and row.get("budget") is not None:
            if row["method"] in DETERMINISTIC_METHODS:
                label = f"tol={interrupted:g}"
            else:
                label = f"N={int(interrupted)}"
            status += f"; серия {label} не завершена"
        details.append(
            {
                "Метод": names.get(row["method"], row.get("name", row["method"])),
                "Бюджет": budget_label(row),
                "Подбор, %": f"{pilot:.3g}" if pilot is not None else "нет данных",
                "Проверка, %": f"{check:.3g}" if check is not None else "нет данных",
                "Попыток проверки": str(row.get("validation_attempts", "нет данных")),
                "Подбор и проверки, с": (
                    f"{search_seconds:.3g}"
                    if search_seconds is not None
                    else "нет данных"
                ),
                "Статус": status,
            }
        )
    st.dataframe(
        pd.DataFrame(details), hide_index=True, width="stretch", key=key + "_details"
    )
